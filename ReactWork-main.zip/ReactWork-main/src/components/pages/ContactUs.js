import React from 'react';
import '../../App.css';

export default function ContactUs() {
  return <h1 className='contact-us'></h1>;

}
