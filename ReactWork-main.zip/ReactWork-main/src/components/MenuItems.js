export const MenuItems = [
 // {
 //   title: 'Orden',
 //   path: '/orden',
 //   cName: 'dropdown-link'
 // },
  //{
  //  title: 'Detalles de las Ordenes',
  //   path: '/dorden',
  //  cName: 'dropdown-link'
   //},
  //{
   // title: 'Folio de reparaciones',
   //path: '/arcade',
   // cName: 'dropdown-link'
 // },
  // {
  //  title: 'Estadística',
   // path: '/support',
  // cName: 'dropdown-link'
 // },

 
];
